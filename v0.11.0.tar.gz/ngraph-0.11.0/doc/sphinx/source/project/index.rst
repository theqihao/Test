.. project/index.rst


More about nGraph
==================

This section contains documentation about the project and how to contribute.

.. toctree::
   :maxdepth: 1

   about.rst
   release-notes.rst
   code-contributor-README.rst
   doc-contributor-README.rst
   ../glossary.rst
