==============
ngraph.runtime
==============

.. automodule:: ngraph.runtime

.. rubric:: Functions

.. autosummary::
   :nosignatures:

   runtime

.. rubric:: Classes

.. autosummary::
   :nosignatures:

   Computation
   Runtime