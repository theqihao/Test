ngraph.ops
==========

.. automodule:: ngraph.ops

   
   

   .. rubric:: Functions

   .. autosummary::
      :nosignatures:
   
      absolute
      acos
      add
      asin
      atan
      avg_pool
      batch_norm
      broadcast
      ceiling
      concat
      constant
      convert
      convolution
      cos
      cosh
      divide
      dot
      equal
      exp
      floor
      function_call
      get_output_element
      greater
      greater_eq
      less
      less_eq
      log
      logical_not
      max
      max_pool
      maximum
      min
      minimum
      multiply
      negative
      not_equal
      one_hot
      pad
      parameter
      power
      prod
      reduce
      relu
      replace_slice
      reshape
      reverse
      select
      sign
      sin
      sinh
      slice
      softmax
      sqrt
      subtract
      sum
      tan
      tanh
   
   


   
   
   


   
   
   